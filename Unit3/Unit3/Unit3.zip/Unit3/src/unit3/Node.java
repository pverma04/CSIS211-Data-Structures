/** ***********************************************
 * File: Node.java
 * Author: Parth Verma
 * Description: This file contains code for the Node class
 * Date: June 23, 2022
 ************************************************ */
package unit3;

public class Node<T> {
//public class Node<T> {
    //data section
    T data;
    //next node
    Node next;
   
    public Node(T data){
        this.data = data;
        //this.next = null;
   }
   
}
